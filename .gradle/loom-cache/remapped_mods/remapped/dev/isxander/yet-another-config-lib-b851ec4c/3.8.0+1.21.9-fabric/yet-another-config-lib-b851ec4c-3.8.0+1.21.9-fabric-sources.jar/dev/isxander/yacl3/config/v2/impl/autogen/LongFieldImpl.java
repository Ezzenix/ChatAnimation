package dev.isxander.yacl3.config.v2.impl.autogen;

import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ControllerBuilder;
import dev.isxander.yacl3.api.controller.LongFieldControllerBuilder;
import dev.isxander.yacl3.config.v2.api.ConfigField;
import dev.isxander.yacl3.config.v2.api.autogen.LongField;
import dev.isxander.yacl3.config.v2.api.autogen.OptionAccess;
import dev.isxander.yacl3.config.v2.api.autogen.SimpleOptionFactory;
import net.minecraft.text.Text;
import net.minecraft.util.Language;

public class LongFieldImpl extends SimpleOptionFactory<LongField, Long> {
    @Override
    protected ControllerBuilder<Long> createController(LongField annotation, ConfigField<Long> field, OptionAccess storage, Option<Long> option) {
        return LongFieldControllerBuilder.create(option)
                .formatValue(v -> {
                    String key = getTranslationKey(field, "fmt." + v);
                    if (Language.getInstance().hasTranslation(key))
                        return Text.translatable(key);
                    key = getTranslationKey(field, "fmt");
                    if (Language.getInstance().hasTranslation(key))
                        return Text.translatable(key, v);
                    return Text.literal(Long.toString(v));
                })
                .range(annotation.min(), annotation.max());
    }
}
