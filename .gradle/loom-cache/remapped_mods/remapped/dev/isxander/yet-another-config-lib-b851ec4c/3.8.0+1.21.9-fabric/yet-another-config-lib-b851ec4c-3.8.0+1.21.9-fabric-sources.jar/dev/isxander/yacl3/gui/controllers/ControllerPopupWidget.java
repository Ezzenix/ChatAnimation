package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.text.Text;

public abstract class ControllerPopupWidget<T extends Controller<?>> extends ControllerWidget<Controller<?>> implements Element {
    public final ControllerWidget<?> entryWidget;
    public ControllerPopupWidget(T control, YACLScreen screen, Dimension<Integer> dim, ControllerWidget<?> entryWidget) {
        super(control, screen, dim);
        this.entryWidget = entryWidget;
    }

    public ControllerWidget<?> entryWidget() {
        return entryWidget;
    }

    public void renderBackground(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {}

    @Override
    public boolean onKeyPressed(int keycode, int scancode, int modifiers) {
        return entryWidget.onKeyPressed(keycode, scancode, modifiers);
    }

    public void close() {}

    public Text popupTitle() {
        return Text.translatable("yacl.control.text.blank");
    }

    @Override
    protected int getHoveredControlWidth() {
        return 0;
    }

}
