package dev.isxander.yacl3.gui.tab;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tab.Tab;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.text.Text;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface TabExt extends Tab {
    @Nullable Tooltip getTooltip();

    default void tick() {}

    default void renderBackground(DrawContext graphics) {}

    //? if >=1.21.6
    @Override
    default @NotNull Text getNarratedHint() {
        return Text.empty();
    }
}
