//? if >=1.21.9 {
package dev.isxander.yacl3.gui;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ElementListWidget;

public abstract class ModernSelectionList<E extends ModernSelectionList.Entry<E>> extends ElementListWidget<E> {
    private boolean doneRefresh;

    public ModernSelectionList(MinecraftClient minecraft, int width, int height, int y, int defaultEntryHeight) {
        super(minecraft, width, height, y, defaultEntryHeight);
    }

    @Override
    public void renderWidget(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        // idk why but the scroll is broken initially and this fixes it.
        if (!doneRefresh) {
            this.method_73367();
            this.doneRefresh = true;
        }

        super.renderWidget(guiGraphics, mouseX, mouseY, partialTick);
    }

    protected void method_73367() {
        // triggers super.repositionEntries() without the need for a mixin accessor
        this.setScrollY(this.getScrollY());
    }

    protected boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(new class_11909(mouseX, mouseY, new class_11910(button, 0)), false);
    }

    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean bl) {
        return this.mouseClicked(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245());
    }

    protected boolean mouseReleased(double mouseX, double mouseY, int button) {
        return super.mouseReleased(new class_11909(mouseX, mouseY, new class_11910(button, 0)));
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        return this.mouseReleased(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245());
    }

    protected boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        return super.mouseDragged(new class_11909(mouseX, mouseY, new class_11910(button, 0)), dx, dy);

    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dx, double dy) {
        return this.mouseDragged(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245(), dx, dy);
    }

    protected boolean keyPressed(int key, int scancode, int modifiers) {
        return super.keyPressed(new class_11908(key, scancode, modifiers));
    }

    @Override
    public boolean method_25404(class_11908 keyEvent) {
        return this.keyPressed(keyEvent.comp_4795(), keyEvent.comp_4796(), keyEvent.comp_4797());
    }

    protected boolean charTyped(char ch, int modifiers) {
        return super.charTyped(new class_11905(ch, modifiers));
    }

    @Override
    public boolean method_25400(class_11905 characterEvent) {
        return this.charTyped((char) characterEvent.comp_4793(), characterEvent.comp_4794());
    }

    public static abstract class Entry<E extends ModernSelectionList.Entry<E>> extends ElementListWidget.Entry<E> {
        protected boolean keyPressed(int key, int scancode, int modifiers) {
            return super.keyPressed(new class_11908(key, scancode, modifiers));
        }

        @Override
        public boolean method_25404(class_11908 keyEvent) {
            return this.keyPressed(keyEvent.comp_4795(), keyEvent.comp_4796(), keyEvent.comp_4797());
        }

        protected boolean charTyped(char ch, int modifiers) {
            return super.charTyped(new class_11905(ch, modifiers));
        }

        @Override
        public boolean method_25400(class_11905 characterEvent) {
            return this.charTyped((char) characterEvent.comp_4793(), characterEvent.comp_4794());
        }
    }
}
//?}
