package dev.isxander.yacl3.gui.utils;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.client.gui.Element;

public final class WidgetUtils {

    public static boolean mouseClicked(Element l, double mouseX, double mouseY, int button) {
        //? if >=1.21.9 {
        return l.mouseClicked(new class_11909(mouseX, mouseY, new class_11910(button, 0)), false);
        //?} else {
        /*return l.mouseClicked(mouseX, mouseY, button);
        *///?}
    }

    public static boolean keyPressed(Element l, int keyCode, int scanCode, int modifiers) {
        //? if >=1.21.9 {
        return l.keyPressed(new class_11908(keyCode, scanCode, modifiers));
        //?} else {
        /*return l.keyPressed(keyCode, scanCode, modifiers);
        *///?}
    }

    public static boolean charTyped(Element l, char codePoint, int modifiers) {
        //? if >=1.21.9 {
        return l.charTyped(new class_11905(codePoint, modifiers));
        //?} else {
        /*return l.charTyped(codePoint, modifiers);
        *///?}
    }

    public static boolean mouseDragged(Element l, double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        //? if >=1.21.9 {
        return l.mouseDragged(new class_11909(mouseX, mouseY, new class_11910(button, 0)), deltaX, deltaY);
        //?} else {
        /*return l.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        *///?}
    }

    private WidgetUtils() {
    }
}
