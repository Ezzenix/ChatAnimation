package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.controllers.string.StringControllerElement;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import dev.isxander.yacl3.gui.utils.KeyUtils;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public abstract class AbstractDropdownControllerElement<T, U> extends StringControllerElement {

	private final AbstractDropdownController<T> dropdownController;
	protected DropdownWidget<T> dropdownWidget;

	protected boolean dropdownVisible = false;

	// Stores a cached list of matching values
	protected List<U> matchingValues = null;

	public AbstractDropdownControllerElement(AbstractDropdownController<T> control, YACLScreen screen, Dimension<Integer> dim) {
		super(control, screen, dim, false);
		this.dropdownController = control;
		this.dropdownController.option.addListener((opt, val) -> this.matchingValues = this.computeMatchingValues());
	}

	public void ensureValidValue() {
		if (!dropdownController.isValueValid(inputField)) {
			if (dropdownWidget == null) {
				inputField = dropdownController.getValidValue(inputField);
			} else {
				inputField = dropdownController.getValidValue(inputField, dropdownWidget.selectedIndex());
				dropdownWidget.resetSelectedIndex();
			}
			caretPos = getDefaultCaretPos();
			this.matchingValues = this.computeMatchingValues();
		}
	}

	@Override
	public boolean onMouseClicked(double mouseX, double mouseY, int button) {
		if (super.onMouseClicked(mouseX, mouseY, button)) {
			if (!dropdownVisible) {
				createDropdownWidget();
				doSelectAll();
			}
			return true;
		}
		return false;
	}

	@Override
	public void setFocused(boolean focused) {
		if (focused) {
			doSelectAll();
			super.setFocused(true);
		} else unfocus();
	}

	@Override
	public void unfocus() {
		if (dropdownVisible) {
			removeDropdownWidget();
		}
		super.unfocus();
	}

	@Override
	public boolean onKeyPressed(int keyCode, int scanCode, int modifiers) {
		if (!inputFieldFocused)
			return false;
		if (dropdownVisible) {
			switch (keyCode) {
				case InputUtil.GLFW_KEY_DOWN -> {
					dropdownWidget.selectNextEntry();
					return true;
				}
				case InputUtil.GLFW_KEY_UP -> {
					dropdownWidget.selectPreviousEntry();
					return true;
				}
				case InputUtil.GLFW_KEY_TAB -> {
					if (KeyUtils.hasShiftDown(modifiers)) {
						dropdownWidget.selectPreviousEntry();
					} else {
						dropdownWidget.selectNextEntry();
					}
					return true;
				}
			}
		} else {
			if (keyCode == InputUtil.GLFW_KEY_ENTER || keyCode == InputUtil.GLFW_KEY_KP_ENTER) {
				createDropdownWidget();
				return true;
			}
		}
		return super.onKeyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean onCharTyped(char chr, String cpStr, int modifiers) {
		if (!inputFieldFocused) {
			return false;
		}
		if (!dropdownVisible) {
			createDropdownWidget();
		}
		return super.onCharTyped(chr, cpStr, modifiers);
	}

	@Override
	protected int getValueColor() {
		if (inputFieldFocused) {
			if (!dropdownController.isValueValid(inputField)) {
				return 0xFFF06080;
			}
		}
		return super.getValueColor();
	}

	@Override
	public boolean modifyInput(Consumer<StringBuilder> builder) {
		boolean success = super.modifyInput(builder);
		if (success) {
			this.matchingValues = this.computeMatchingValues();
		}
		return success;
	}

	public abstract List<U> computeMatchingValues();

	public boolean matchingValue(String value) {
		return value.toLowerCase().contains(inputField.toLowerCase());
	}

	@Override
	public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
		if (matchingValues == null) matchingValues = computeMatchingValues();

		super.render(graphics, mouseX, mouseY, delta);
	}

	void renderDropdownEntry(DrawContext graphics, Dimension<Integer> entryDimension, int index) {
		renderDropdownEntry(graphics, entryDimension, matchingValues.get(index));
	}
	protected void renderDropdownEntry(DrawContext graphics, Dimension<Integer> entryDimension, U value) {
		String entry = getString(value);
		Text text;
		if (entry.isBlank()) {
			text = Text.translatable("yacl.control.text.blank").formatted(Formatting.GRAY);
		} else {
			text = shortenString(entry);
		}
		graphics.drawText(
				textRenderer,
				text,
				entryDimension.xLimit() - textRenderer.getWidth(text) - getDropdownEntryPadding(),
				getTextY(entryDimension),
				-1,
				true
		);
	}

	protected int getTextY(Dimension<Integer> dim) {
		return (int)(dim.y() + dim.height() / 2f - textRenderer.fontHeight / 2f);
	}

	@Override
	public void setDimension(Dimension<Integer> dim) {
		super.setDimension(dim);

		if (dropdownWidget != null) {
			dropdownWidget.setDimension(dropdownWidget.getDimension().withY(this.getDimension().y()));
			// checks if the popup is being partially rendered offscreen
			if (this.getDimension().y() < screen.tabArea.getTop() || this.getDimension().yLimit() > screen.tabArea.getBottom()) {
				removeDropdownWidget();
			}
		}
	}

	public abstract String getString(U object);

	public Text shortenString(String value) {
		return Text.literal(GuiUtils.shortenString(value, textRenderer, getDimension().width() - 20, "..."));
	}

	protected int getDecorationPadding() {
		return super.getXPadding();
	}

	protected int getDropdownEntryPadding() {
		return 0;
	}

	public void createDropdownWidget() {
		dropdownVisible = true;
		dropdownWidget = new DropdownWidget<>(dropdownController, screen, getDimension(), this);
		screen.addPopupControllerWidget(dropdownWidget);
	}

	public DropdownWidget<T> dropdownWidget() {
		return dropdownWidget;
	}

	public boolean isDropdownVisible() {
		return dropdownVisible;
	}

	public void removeDropdownWidget() {
		ensureValidValue();
		screen.clearPopupControllerWidget();
		this.dropdownVisible = false;
		this.dropdownWidget = null;
	}
}
