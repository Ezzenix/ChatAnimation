package dev.isxander.yacl3.gui.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;

public interface GuiRenderStateSink {
    //? if >=1.21.6 {
    void yacl$submit(SimpleGuiElementRenderState renderState);

    static void submit(DrawContext graphics, SimpleGuiElementRenderState renderState) {
        ((GuiRenderStateSink) graphics).yacl$submit(renderState);
    }

    ScreenRect yacl$peekScissorStack();

    static ScreenRect peekScissorStack(DrawContext graphics) {
        return ((GuiRenderStateSink) graphics).yacl$peekScissorStack();
    }
    //?} else {
    /*MultiBufferSource yacl$bufferSource();

    static MultiBufferSource bufferSource(GuiGraphics graphics) {
        return ((GuiRenderStateSink) graphics).yacl$bufferSource();
    }
    *///?}
}
