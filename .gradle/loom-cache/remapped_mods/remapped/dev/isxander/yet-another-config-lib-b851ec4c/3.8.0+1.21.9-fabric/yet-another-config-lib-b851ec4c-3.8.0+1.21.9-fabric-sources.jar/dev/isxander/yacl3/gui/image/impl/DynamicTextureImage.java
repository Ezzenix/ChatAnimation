package dev.isxander.yacl3.gui.image.impl;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.isxander.yacl3.debug.DebugProperties;
import dev.isxander.yacl3.gui.image.ImageRenderer;
import dev.isxander.yacl3.gui.image.ImageRendererFactory;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;

public class DynamicTextureImage implements ImageRenderer {
    protected static final TextureManager textureManager = MinecraftClient.getInstance().getTextureManager();

    protected NativeImage image;
    protected NativeImageBackedTexture texture;
    protected final Identifier uniqueLocation;
    protected final int width, height;
    protected final boolean textureFiltering;

    public DynamicTextureImage(NativeImage image, Identifier location, boolean textureFiltering) {
        RenderSystem.assertOnRenderThread();

        this.image = image;
        this.texture = new NativeImageBackedTexture(/*? if >=1.21.5 >>*/ location::toString, image);
        this.texture.setFilter(textureFiltering, false);
        this.textureFiltering = textureFiltering;
        this.uniqueLocation = location;
        textureManager.registerTexture(this.uniqueLocation, this.texture);
        this.width = image.getWidth();
        this.height = image.getHeight();
    }

    @Override
    public int render(DrawContext graphics, int x, int y, int renderWidth, float tickDelta) {
        if (image == null) return 0;

        float ratio = renderWidth / (float)this.width;
        int targetHeight = (int) (this.height * ratio);

        GuiUtils.pushPose(graphics);
        GuiUtils.translate2D(graphics, x, y);
        GuiUtils.scale2D(graphics, ratio, ratio);

        GuiUtils.blitGuiTex(
                graphics,
                uniqueLocation,
                0, 0,
                0, 0,
                this.width, this.height,
                this.width, this.height,
                textureFiltering
        );

        GuiUtils.popPose(graphics);

        return targetHeight;
    }

    @Override
    public void close() {
        image.close();
        image = null;
        texture = null;
        textureManager.destroyTexture(uniqueLocation);
    }

    public static ImageRendererFactory fromPath(Path imagePath, Identifier location, boolean textureFiltering) {
        return (ImageRendererFactory.OnThread) () -> () -> new DynamicTextureImage(NativeImage.read(new FileInputStream(imagePath.toFile())), location, textureFiltering);
    }
}
