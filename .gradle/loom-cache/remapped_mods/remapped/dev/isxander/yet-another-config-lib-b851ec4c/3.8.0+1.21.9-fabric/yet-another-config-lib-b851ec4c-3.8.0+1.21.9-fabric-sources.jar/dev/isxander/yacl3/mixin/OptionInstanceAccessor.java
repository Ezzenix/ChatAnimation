package dev.isxander.yacl3.mixin;

import net.minecraft.client.option.SimpleOption;
import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@ApiStatus.Internal
@Mixin(SimpleOption.class)
public interface OptionInstanceAccessor<T> {
    @Accessor
    T getInitialValue();
}
