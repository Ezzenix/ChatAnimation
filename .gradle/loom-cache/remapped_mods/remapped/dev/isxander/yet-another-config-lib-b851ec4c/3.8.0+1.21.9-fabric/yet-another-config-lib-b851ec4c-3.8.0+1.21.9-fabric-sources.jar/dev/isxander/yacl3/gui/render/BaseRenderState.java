package dev.isxander.yacl3.gui.render;

import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

//? if >=1.21.6 {
import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;
//?} else {
/*import net.minecraft.client.renderer.RenderType;
import org.joml.Matrix4f;
*///?}

public record BaseRenderState(
        //? if >=1.21.6 {
        RenderPipeline pipeline,
        TextureSetup textureSetup,
        Matrix3x2f pose,
        @Nullable ScreenRect bounds,
        @Nullable ScreenRect scissorArea
        //?} else {
        /*net.minecraft.client.renderer.RenderType renderType,
        Matrix4f pose
        *///?}
) {
    public static BaseRenderState create(DrawContext graphics, @Nullable Identifier texture, int x0, int y0, int x1, int y1) {
        //? if >=1.21.6 {
        @Nullable ScreenRect scissorArea = GuiRenderStateSink.peekScissorStack(graphics);
        ScreenRect bounds = boundsFromMaxPoints(x0, y0, x1, y1, graphics.getMatrices(), scissorArea);

        return new BaseRenderState(
                texture != null ? RenderPipelines.GUI_TEXTURED : RenderPipelines.GUI,
                textureSetup(texture),
                new Matrix3x2f(graphics.getMatrices()),
                bounds, scissorArea
        );
        //?} else {
        /*return create(graphics, texture);
        *///?}
    }

    public static BaseRenderState create(DrawContext graphics, @Nullable Identifier texture) {
        //? if >=1.21.6 {
        return new BaseRenderState(
                texture != null ? RenderPipelines.GUI_TEXTURED : RenderPipelines.GUI,
                textureSetup(texture),
                new Matrix3x2f(graphics.getMatrices()),
                null, GuiRenderStateSink.peekScissorStack(graphics)
        );
        //?} else {
        /*return new BaseRenderState(
                texture != null ? GuiUtils.guiTextured(false).apply(texture) : RenderType.gui(),
                graphics.pose().last().pose()
        );
        *///?}
    }

    //? if >=1.21.6 {
    private static TextureSetup textureSetup(@Nullable Identifier texture) {
        return texture == null
                ? TextureSetup.empty()
                : TextureSetup.withoutGlTexture(MinecraftClient.getInstance().getTextureManager().getTexture(texture).getGlTextureView());
    }

    private static ScreenRect boundsFromMaxPoints(int x0, int y0, int x1, int y1, Matrix3x2f pose, @Nullable ScreenRect scissorArea) {
        ScreenRect bounds = new ScreenRect(x0, y0, x1 - x0, y1 - y0).transformEachVertex(pose);
        return scissorArea != null ? scissorArea.intersection(bounds) : bounds;
    }
    //?}
}
