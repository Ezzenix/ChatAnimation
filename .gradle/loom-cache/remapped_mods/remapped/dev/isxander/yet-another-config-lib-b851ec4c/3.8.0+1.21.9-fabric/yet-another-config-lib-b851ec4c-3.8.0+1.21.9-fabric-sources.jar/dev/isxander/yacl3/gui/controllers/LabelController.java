package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.client.font.MultilineText;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.screen.narration.NarrationPart;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/**
 * Simply renders some text as a label.
 */
public class LabelController implements Controller<Text> {
    private final Option<Text> option;
    /**
     * Constructs a label controller
     *
     * @param option bound option
     */
    public LabelController(Option<Text> option) {
        this.option = option;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Option<Text> option() {
        return option;
    }

    @Override
    public Text formatValue() {
        return option().pendingValue();
    }

    @Override
    public AbstractWidget provideWidget(YACLScreen screen, Dimension<Integer> widgetDimension) {
        return new LabelControllerElement(screen, widgetDimension);
    }

    public class LabelControllerElement extends AbstractWidget {
        private List<OrderedText> wrappedText;
        protected MultilineText wrappedTooltip;
        protected boolean focused;

        protected final YACLScreen screen;

        public LabelControllerElement(YACLScreen screen, Dimension<Integer> dim) {
            super(dim);
            this.screen = screen;
            option().addListener((opt, pending) -> updateTooltip());
            updateTooltip();
            updateText();
        }

        @Override
        public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
            updateText();

            int y = getDimension().y();
            for (OrderedText text : wrappedText) {
                graphics.drawText(textRenderer, text, getDimension().x() + getXPadding(), y + getYPadding(), option().available() ? -1 : 0xFFA0A0A0, true);
                y += textRenderer.fontHeight;
            }

            if (isFocused()) {
                graphics.fill(getDimension().x() - 1, getDimension().y() - 1, getDimension().xLimit() + 1, getDimension().y(), -1);
                graphics.fill(getDimension().x() - 1, getDimension().y() - 1, getDimension().x(), getDimension().yLimit() + 1, -1);
                graphics.fill(getDimension().x() - 1, getDimension().yLimit(), getDimension().xLimit() + 1, getDimension().yLimit() + 1, -1);
                graphics.fill(getDimension().xLimit(), getDimension().y() - 1, getDimension().xLimit() + 1, getDimension().yLimit() + 1, -1);
            }

            GuiUtils.pushPose(graphics);
            GuiUtils.translateZ(graphics, 100);
            if (isMouseOver(mouseX, mouseY)) {
                Style style = getStyle(mouseX, mouseY);
                if (style != null && style.getHoverEvent() != null) {
                    HoverEvent hoverEvent = style.getHoverEvent();

                    //? if >=1.21.6 {
                    graphics.drawHoverEvent(textRenderer, style, mouseX, mouseY);
                    //?} elif >=1.21.5 {
                    /*if (hoverEvent instanceof HoverEvent.ShowItem showItem) {
                        ItemStack stack = showItem.item();
                        renderItemStackTooltip(graphics, mouseX, mouseY, stack);
                    } else if (hoverEvent instanceof HoverEvent.ShowEntity showEntity) {
                        HoverEvent.EntityTooltipInfo entity = showEntity.entity();
                        renderEntityTooltip(graphics, mouseX, mouseY, entity);
                    } else if (hoverEvent instanceof HoverEvent.ShowText showText) {
                        Component text = showText.value();
                        renderTextTooltip(graphics, mouseX, mouseY, text);
                    }
                    *///?} else {
                    /*@Nullable HoverEvent.ItemStackInfo itemStackContent = hoverEvent.getValue(HoverEvent.Action.SHOW_ITEM);
                    @Nullable HoverEvent.EntityTooltipInfo entityContent = hoverEvent.getValue(HoverEvent.Action.SHOW_ENTITY);
                    @Nullable Component text = hoverEvent.getValue(HoverEvent.Action.SHOW_TEXT);

                    if (itemStackContent != null) {
                        ItemStack stack = itemStackContent.getItemStack();
                        renderItemStackTooltip(graphics, mouseX, mouseY, stack);
                    } else if (entityContent != null) {
                        renderEntityTooltip(graphics, mouseX, mouseY, entityContent);
                    } else if (text != null) {
                        renderTextTooltip(graphics, mouseX, mouseY, text);
                    }
                    *///?}
                }

                //? if >=1.21.9 {
                if (style != null && style.getClickEvent() != null) {
                    graphics.method_74037(net.minecraft.class_11876.field_62455);
                }
                //?}
            }
            GuiUtils.popPose(graphics);
        }

        //? if <=1.21.5 {
        /*private void renderItemStackTooltip(GuiGraphics graphics, int mouseX, int mouseY, ItemStack itemStack) {
            graphics.renderTooltip(textRenderer, Screen.getTooltipFromItem(client, itemStack), itemStack.getTooltipImage(), mouseX, mouseY);
        }
        private void renderEntityTooltip(GuiGraphics graphics, int mouseX, int mouseY, HoverEvent.EntityTooltipInfo entity) {
            if (this.client.options.advancedItemTooltips) {
                graphics.renderComponentTooltip(textRenderer, entity.getTooltipLines(), mouseX, mouseY);
            }
        }
        private void renderTextTooltip(GuiGraphics graphics, int mouseX, int mouseY, Component text) {
            MultiLineLabel multilineText = MultiLineLabel.create(textRenderer, text, getDimension().width());
            YACLScreen.renderMultilineTooltip(graphics, textRenderer, multilineText, getDimension().centerX(), getDimension().y(), getDimension().yLimit(), screen.width, screen.height);
        }
        *///?}

        @Override
        public boolean onMouseClicked(double mouseX, double mouseY, int button) {
            if (!isMouseOver(mouseX, mouseY))
                return false;

            Style style = getStyle((int) mouseX, (int) mouseY);

            if(style == null)
                return false;

            return screen.handleTextClick(style);
        }

        @Nullable
        protected Style getStyle(int mouseX, int mouseY) {
            if (!getDimension().isPointInside(mouseX, mouseY))
                return null;

            int x = mouseX - getDimension().x() - getXPadding();
            int y = mouseY - getDimension().y() - getYPadding();
            int line = y / textRenderer.fontHeight;

            if (x < 0 || x > getDimension().xLimit()) return null;
            if (y < 0 || y > getDimension().yLimit()) return null;
            if (line < 0 || line >= wrappedText.size()) return null;

            return textRenderer.getTextHandler().getStyleAt(wrappedText.get(line), x);
        }

        private int getXPadding() {
            return 4;
        }

        private int getYPadding() {
            return 3;
        }

        private void updateText() {
            wrappedText = textRenderer.wrapLines(formatValue(), getDimension().width() - getXPadding() * 2);
            setDimension(getDimension().withHeight(wrappedText.size() * textRenderer.fontHeight + getYPadding() * 2));
        }

        private void updateTooltip() {
            this.wrappedTooltip = MultilineText.create(textRenderer, option().tooltip(), screen.width / 3 * 2 - 10);
        }

        @Override
        public boolean matchesSearch(String query) {
            return formatValue().getString().toLowerCase().contains(query.toLowerCase());
        }

        @Nullable
        @Override
        public GuiNavigationPath getNavigationPath(GuiNavigation focusNavigationEvent) {
            if (!option().available())
                return null;
            return !this.isFocused() ? GuiNavigationPath.of(this) : null;
        }

        @Override
        public boolean isFocused() {
            return focused;
        }

        @Override
        public void setFocused(boolean focused) {
            this.focused = focused;
        }

        @Override
        public void appendNarrations(NarrationMessageBuilder builder) {
            builder.put(NarrationPart.TITLE, formatValue());
        }

        @Override
        public SelectionType getType() {
            return SelectionType.FOCUSED;
        }
    }
}
