//? if >=1.21.9 {
package dev.isxander.yacl3.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ElementListWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;

public abstract class ModernSelectionList<E extends ModernSelectionList.Entry<E>> extends ElementListWidget<E> {
    private boolean doneRefresh;

    public ModernSelectionList(MinecraftClient minecraft, int width, int height, int y, int defaultEntryHeight) {
        super(minecraft, width, height, y, defaultEntryHeight);
    }

    @Override
    public void renderWidget(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        // idk why but the scroll is broken initially and this fixes it.
        if (!doneRefresh) {
            this.recalculateAllChildrenPositions();
            this.doneRefresh = true;
        }

        super.renderWidget(guiGraphics, mouseX, mouseY, partialTick);
    }

    protected void recalculateAllChildrenPositions() {
        // triggers super.repositionEntries() without the need for a mixin accessor
        this.setScrollY(this.getScrollY());
    }

    protected boolean mouseClicked(double mouseX, double mouseY, int button) {
        return super.mouseClicked(new Click(mouseX, mouseY, new MouseInput(button, 0)), false);
    }

    @Override
    public boolean mouseClicked(Click mouseButtonEvent, boolean bl) {
        return this.mouseClicked(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button());
    }

    protected boolean mouseReleased(double mouseX, double mouseY, int button) {
        return super.mouseReleased(new Click(mouseX, mouseY, new MouseInput(button, 0)));
    }

    @Override
    public boolean mouseReleased(Click mouseButtonEvent) {
        return this.mouseReleased(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button());
    }

    protected boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        return super.mouseDragged(new Click(mouseX, mouseY, new MouseInput(button, 0)), dx, dy);

    }

    @Override
    public boolean mouseDragged(Click mouseButtonEvent, double dx, double dy) {
        return this.mouseDragged(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button(), dx, dy);
    }

    protected boolean keyPressed(int key, int scancode, int modifiers) {
        return super.keyPressed(new KeyInput(key, scancode, modifiers));
    }

    @Override
    public boolean keyPressed(KeyInput keyEvent) {
        return this.keyPressed(keyEvent.key(), keyEvent.scancode(), keyEvent.modifiers());
    }

    protected boolean charTyped(char ch, int modifiers) {
        return super.charTyped(new CharInput(ch, modifiers));
    }

    @Override
    public boolean charTyped(CharInput characterEvent) {
        return this.charTyped((char) characterEvent.codepoint(), characterEvent.modifiers());
    }

    public static abstract class Entry<E extends ModernSelectionList.Entry<E>> extends ElementListWidget.Entry<E> {
        protected boolean keyPressed(int key, int scancode, int modifiers) {
            return super.keyPressed(new KeyInput(key, scancode, modifiers));
        }

        @Override
        public boolean keyPressed(KeyInput keyEvent) {
            return this.keyPressed(keyEvent.key(), keyEvent.scancode(), keyEvent.modifiers());
        }

        protected boolean charTyped(char ch, int modifiers) {
            return super.charTyped(new CharInput(ch, modifiers));
        }

        @Override
        public boolean charTyped(CharInput characterEvent) {
            return this.charTyped((char) characterEvent.codepoint(), characterEvent.modifiers());
        }
    }
}
//?}
